import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:disasterapp/models/alert_model.dart';

class AlertService {
  static const String apiUrl = "https://api.weather.gov/alerts";

  Future<List<Alert>> fetchAlerts() async {
    try {
      final response = await http.get(Uri.parse(apiUrl));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final List alertsJson = data["features"];

        return alertsJson.map((json) => Alert.fromJson(json["properties"])).toList();
      } else {
        throw Exception("Failed to load alerts");
      }
    } catch (e) {
      throw Exception("Error fetching alerts: $e");
    }
  }
}
