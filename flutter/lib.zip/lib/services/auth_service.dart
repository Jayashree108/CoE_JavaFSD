import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class AuthService with ChangeNotifier {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  User? _user;

  AuthService() {
    _user = _auth.currentUser;
    _auth.authStateChanges().listen((User? user) {
      _user = user;
      notifyListeners(); // ✅ Notify UI when auth state changes
    });
  }

  // ✅ Check if user is authenticated
  bool get isAuthenticated => _user != null;

  // ✅ Get current user
  User? get user => _user;

  // ✅ Login User
  Future<String?> login(String email, String password) async {
    try {
      await _auth.signInWithEmailAndPassword(email: email, password: password);
      return null; // Success
    } on FirebaseAuthException catch (e) {
      return e.message; // Return error message
    }
  }

  // ✅ Register User
  Future<String?> register(String email, String password) async {
    try {
      await _auth.createUserWithEmailAndPassword(email: email, password: password);
      return null; // Success
    } on FirebaseAuthException catch (e) {
      return e.message; // Return error message
    }
  }

  // ✅ Logout User
  Future<void> logout() async {
    await _auth.signOut();
    notifyListeners(); // ✅ Notify UI after logout
  }
}
