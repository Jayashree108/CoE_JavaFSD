import 'package:flutter/material.dart';
import 'package:disasterapp/screens/alert_screen.dart'; 
import 'package:disasterapp/models/alert_model.dart';
import 'package:disasterapp/services/alert_service.dart';
class AlertScreen extends StatefulWidget {
  @override
  _AlertScreenState createState() => _AlertScreenState();
}

class _AlertScreenState extends State<AlertScreen> {
  late Future<List<Alert>> futureAlerts;
  String selectedRegion = "All";

  @override
  void initState() {
    super.initState();
    futureAlerts = AlertService().fetchAlerts();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Disaster Alerts"),
        actions: [
          DropdownButton<String>(
            value: selectedRegion,
            items: ["All", "Texas, USA", "California, USA", "Florida, USA"]
                .map((region) => DropdownMenuItem(
                      value: region,
                      child: Text(region),
                    ))
                .toList(),
            onChanged: (value) {
              setState(() {
                selectedRegion = value!;
              });
            },
          ),
        ],
      ),
      body: FutureBuilder<List<Alert>>(
        future: futureAlerts,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text("Error loading alerts"));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(child: Text("No alerts found"));
          }

          final alerts = snapshot.data!
              .where((alert) => selectedRegion == "All" || alert.area == selectedRegion)
              .toList();

          return ListView.builder(
            itemCount: alerts.length,
            itemBuilder: (context, index) {
              final alert = alerts[index];
              return Card(
                margin: EdgeInsets.all(8),
                child: ListTile(
                  title: Text(alert.headline, style: TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Text(alert.description),
                  trailing: Chip(
                    label: Text(alert.severity),
                    backgroundColor: _getSeverityColor(alert.severity),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }

  Color _getSeverityColor(String severity) {
    switch (severity.toLowerCase()) {
      case "severe":
        return Colors.red;
      case "moderate":
        return Colors.orange;
      case "minor":
        return Colors.green;
      default:
        return Colors.grey;
    }
  }
}
