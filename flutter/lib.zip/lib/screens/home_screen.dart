// import 'package:flutter/material.dart';
// import 'package:provider/provider.dart';
// import 'package:disasterapp/services/auth_service.dart';
// import 'package:flutter_gen/gen_l10n/app_localizations.dart';
// import 'package:disasterapp/screens/alert_screen.dart';  // ✅ Correct Import


// class HomeScreen extends StatelessWidget {
//   const HomeScreen({super.key});

//   @override
//   Widget build(BuildContext context) {
//     final authService = Provider.of<AuthService>(context, listen: false);

//     return Scaffold(
//       appBar: AppBar(
//         title: Text(AppLocalizations.of(context)!.homeTitle),
//         actions: [
//           IconButton(
//             icon: const Icon(Icons.logout),
//             onPressed: () async {
//               await authService.logout();
//               Navigator.pushReplacementNamed(context, '/login');
//             },
//           ),
//         ],
//       ),
//       body: Padding(
//         padding: const EdgeInsets.all(16.0),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             Text(
//               AppLocalizations.of(context)!.welcomeMessage,
//               style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
//             ),
//             const SizedBox(height: 20),
//             const TipsSection(),
//             const SizedBox(height: 20),
//             Center(
//               child: ElevatedButton.icon(
//                 icon: const Icon(Icons.warning),
//                 label: const Text("View Disaster Alerts"),
//                 onPressed: () {
//                   Navigator.push(
//                     context,
//                     MaterialPageRoute(builder: (context) => AlertScreen()),
//                   );
//                 },
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }

// // ✅ Disaster Tips Section
// class TipsSection extends StatelessWidget {
//   const TipsSection({super.key});

//   @override
//   Widget build(BuildContext context) {
//     final List<String> tips = [
//       "Stay indoors during storms.",
//       "Have an emergency kit ready.",
//       "Follow evacuation orders.",
//       "Keep important documents safe.",
//       "Stay updated with alerts."
//     ];

//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         const Text(
//           "Disaster Safety Tips:",
//           style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
//         ),
//         const SizedBox(height: 10),
//         ...tips.map((tip) => ListTile(
//               leading: const Icon(Icons.warning, color: Colors.red),
//               title: Text(tip),
//             )),
//       ],
//     );
//   }
// }
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:disasterapp/services/auth_service.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:disasterapp/screens/alert_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final authService = Provider.of<AuthService>(context, listen: false);

    return Scaffold(
      appBar: AppBar(
        title: Text(
          AppLocalizations.of(context)!.homeTitle,
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.redAccent, // 🔥 Disaster-themed color
        actions: [
          IconButton(
            icon: const Icon(Icons.logout, color: Colors.white),
            onPressed: () async {
              await authService.logout();
              Navigator.pushReplacementNamed(context, '/login');
            },
          ),
        ],
      ),
      body: Stack(
        children: [
          // 🌍 Background Image
          Positioned.fill(
            child: Opacity(
              opacity: 0.3,
              child: Image.network(
                "https://media.istockphoto.com/id/1333043586/photo/tornado-in-stormy-landscape-climate-change-and-natural-disaster-concept.jpg?s=612x612&w=0&k=20&c=uo4HoloU79NEle1-rgVoLhKBE-RrfPSeinKAdczCo2I=", // ✅ Replace with your image URL
                fit: BoxFit.cover,
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  AppLocalizations.of(context)!.welcomeMessage,
                  style: const TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: Colors.red, // 🔴 Attention-grabbing text
                  ),
                ),
                const SizedBox(height: 20),
                const Expanded(child: TipsSection()),
                const SizedBox(height: 20),
                Center(
                  child: ElevatedButton.icon(
                    icon: const Icon(Icons.warning, color: Colors.white),
                    label: const Text("View Disaster Alerts"),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.redAccent, // 🚨 Alert color
                      padding: const EdgeInsets.symmetric(
                          horizontal: 20, vertical: 12),
                      textStyle: const TextStyle(fontSize: 16),
                    ),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) =>  AlertScreen()),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ✅ Disaster Safety Tips Section
class TipsSection extends StatelessWidget {
  const TipsSection({super.key});

  @override
  Widget build(BuildContext context) {
    final Map<String, List<String>> disasterTips = {
      "🌊 Flood": [
        "Move to higher ground immediately.",
        "Avoid walking or driving through floodwaters.",
        "Disconnect electrical appliances.",
        "Have a waterproof emergency kit ready.",
      ],
      "🌪 Hurricane": [
        "Stay indoors away from windows.",
        "Secure outdoor furniture.",
        "Stock up on food, water, and medicines.",
        "Follow evacuation orders from local authorities.",
      ],
      "🔥 Wildfire": [
        "Create a defensible space around your home.",
        "Have an emergency bag ready with essentials.",
        "Keep flammable materials away from home exteriors.",
        "Close all windows and vents to prevent smoke inhalation.",
      ],
      "❄ Blizzard": [
        "Stay indoors and keep warm.",
        "Avoid traveling unless absolutely necessary.",
        "Keep extra blankets, food, and water at home.",
        "Ensure proper ventilation if using a heater.",
      ],
      "🌍 Earthquake": [
        "Drop, Cover, and Hold under sturdy furniture.",
        "Stay indoors and away from glass windows.",
        "Turn off gas and electricity if safe to do so.",
        "Prepare an emergency bag with first-aid and water.",
      ],
      "🌊 Tsunami": [
        "Move to higher ground immediately.",
        "Do not return to coastal areas until authorities declare it safe.",
        "Listen to emergency broadcasts for updates.",
        "Stay away from bridges and low-lying areas.",
      ],
    };

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: disasterTips.entries.map((entry) {
          return Card(
            color: Colors.white.withOpacity(0.9),
            margin: const EdgeInsets.symmetric(vertical: 8),
            child: Padding(
              padding: const EdgeInsets.all(12.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    entry.key, // Disaster type with emoji
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.redAccent, // 🔴 Make it stand out
                    ),
                  ),
                  const SizedBox(height: 5),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: entry.value.map((tip) {
                      return Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Icon(Icons.check, color: Colors.green, size: 18),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              tip,
                              style: const TextStyle(fontSize: 16),
                            ),
                          ),
                        ],
                      );
                    }).toList(),
                  ),
                ],
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}

