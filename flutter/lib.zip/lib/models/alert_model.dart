class Alert {
  final String headline;
  final String event;
  final String area;
  final String description;
  final String severity;

  Alert({
    required this.headline,
    required this.event,
    required this.area,
    required this.description,
    required this.severity,
  });

  factory Alert.fromJson(Map<String, dynamic> json) {
    return Alert(
      headline: json["headline"] ?? "No Headline",
      event: json["event"] ?? "Unknown",
      area: json["areaDesc"] ?? "Unknown Area",
      description: json["description"] ?? "No Description",
      severity: json["severity"] ?? "Unknown Severity",
    );
  }
}
