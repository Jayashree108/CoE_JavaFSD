import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  private booksUrl = 'C:\Users\jaysh\OneDrive\Desktop\angluar_projects\author\src\assets\books.json'; // Path to the local JSON file

  constructor(private http: HttpClient) {}

  getBooks(): Observable<any[]> {
    return this.http.get<any[]>(this.booksUrl);
  }
}
